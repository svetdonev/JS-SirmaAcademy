function solve (number) {
    for(let i = number; i >= 1; i--) {
        console.log(i);
    }
}

solve(10);