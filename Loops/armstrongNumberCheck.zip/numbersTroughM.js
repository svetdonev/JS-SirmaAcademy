function solve(n, m) {
    for(let i = 1; i <= n; i+=m) {
        console.log(i);
    }
}

solve(10, 2);
solve(8, 3);