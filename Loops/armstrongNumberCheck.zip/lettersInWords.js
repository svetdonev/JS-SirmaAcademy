function solve(word) {
    for(let i = 0; i < word.length; i++) {
        console.log(word[[i]]);
    }
}

solve('hello');
solve('Bulgaria');