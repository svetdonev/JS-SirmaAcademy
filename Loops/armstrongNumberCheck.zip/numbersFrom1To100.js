function solve (number) {
    for(let i = 1; i <= number; i++) {
        console.log(i);
    }
}

solve(100);