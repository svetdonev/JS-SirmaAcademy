function solve(input) {
    input.reverse();

    console.log(input);
}

solve(['a', 'b', 'c', 'd', 'e']);
solve(['abc', 'def', 'hig', 'klm', 'nop']);