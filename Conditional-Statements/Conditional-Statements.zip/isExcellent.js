function isExcellent(grade) {
    if(grade >= 5.50) {
        console.log("Excellent!");
    }
}

isExcellent(6);
isExcellent(5.50);
isExcellent(5.49);
isExcellent(2.99);