function largestNumber(num1, num2) {
    let largestNum = Math.max(num1, num2);

    console.log(largestNum);
}

largestNumber(2, 4);
largestNumber(7, 12);
largestNumber(-1, -5);